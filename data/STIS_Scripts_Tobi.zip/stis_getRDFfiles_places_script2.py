#!/usr/bin/python
# coding: utf-8

import urllib
import arcpy
import os

# Benachrichtigung ausgeben
def log(message, severity=0):
	try:
		for line in message.split('\n'):
			if severity == 0:
				arcpy.AddMessage(line)
			elif severity == 1:
				arcpy.AddWarning(line)
			elif severity == 2:
				arcpy.AddError(line)
	except:
		pass

folder = 'E:/RDF/places/'
FAILSTRING = '<?xml version="1.0" encoding="utf-8" ?>\n<rdf:RDF\n\txmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"\n\txmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#" >\n</rdf:RDF>'

# Read input file.
# print('Reading input file...')
log('Reading input file...')
input_file = open(folder + 'stis_placename_list.txt', 'r')
link_file = open(folder + 'stis_places_links.txt', 'w')
rdf_link_file = open(folder + 'stis_places_rdf_links.txt', 'w')

# For each line in the input file...
# e.g. '<http://d-nb.info/gnd/172452023> gnd:preferredNameForThePlaceOrGeographicName "Gelsenkirchen" .'
# print('Processing links...')
log('Processing links...')
for line in input_file:
	# format a SPARQL link for dbpedia...
	gnd_link = line.split(' ')[0]
	dbpedia_id = line.rsplit(' ',2)[1].replace('\"','')
	# print(' - processing: ' + gnd_identifier)
	log(' - processing: ' + dbpedia_id)
	dbpedia_link = 'http://de.dbpedia.org/resource/' + dbpedia_id
	rdf_link = 'http://de.dbpedia.org/data/' + dbpedia_id + '.rdf'
	# try to retrieve rdf file
	filename = folder + dbpedia_id + '.rdf'
	log('    filename = ' + filename)
	urllib.urlretrieve(rdf_link, filename)
	log('               RDF found!')
	fileObj = open(filename, 'r')
	if fileObj.read() == FAILSTRING:
		# delete file...
		log('             DELETED: ' +  dbpedia_id)
		fileObj.close()
		os.remove(filename)
	else:
		# save link in link file
		log('               FOUND: ' +  dbpedia_id)
		link_file.write(gnd_link + ' owl.sameAs <' + dbpedia_link + '>\n')
		rdf_link_file.write(rdf_link + '\n')
		fileObj.close()
		
	
# Close all open files.
# print('Closing files...')
log('Closing files...')
input_file.close()
link_file.close()
rdf_link_file.close()
print('DONE!')