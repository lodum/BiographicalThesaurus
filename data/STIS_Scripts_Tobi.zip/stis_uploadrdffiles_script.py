			# format a SPARQL update query for query file
			update_query = 'LOAD <' + dbpedia_link + '> INTO <> .'
			query_file.write(update_query + '\n')