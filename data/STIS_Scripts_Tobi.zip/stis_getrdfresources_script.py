import urllib
	
# Read input file.
print('Reading input file...')
inputfile = open('XXXXX.txt', 'r') # TBD: insert correct filename!!!

# For each line in the input file...
print('Processing requests...')
for line in inputfile:
	# retrieve the rdf-resource as file...
	filename = 'E:/' + line.rsplit('/',1)[1]
	print(' - processing: %s'.format(filename.replace('E:/RDF/','')))
	urllib.urlretrieve(line, filename)
	
print('DONE!')