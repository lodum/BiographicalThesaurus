#!/usr/bin/python

import urllib
import arcpy

# Benachrichtigung ausgeben
def log(message, severity=0):
	try:
		for line in message.split('\n'):
			if severity == 0:
				arcpy.AddMessage(line)
			elif severity == 1:
				arcpy.AddWarning(line)
			elif severity == 2:
				arcpy.AddError(line)
	except:
		pass

folder = 'E:/RDF/'

# Read input file.
# print('Reading input file...')
log('Reading input file...')
input_file = open(folder + 'testnew.txt', 'r')
link_file = open(folder + 'stis_links.txt', 'w')
link_file.write('@prefix owl: <http://www.w3.org/2002/07/owl#> .\n')

# For each line in the input file...
# e.g. <http://d-nb.info/gnd/120490110> gnd:gndIdentifier "120490110" .
# print('Processing links...')
log('Processing links...')
for line in input_file:
	# format a SPARQL query for dbpedia...
	gnd_identifier = line.split(" ")[0].rsplit("/", 1)[1].replace(">", "")
	# print(' - processing: ' + gnd_identifier)
	log(' - processing: ' + gnd_identifier)
	query = urllib.quote('SELECT DISTINCT * WHERE{?a <http://dbpedia.org/ontology/individualisedPnd> "' + gnd_identifier + '"@de}')
	query_url = 'http://de.dbpedia.org/sparql/?default-graph-uri=&query=' + query + '&format=text%2Fhtml&timeout=0&debug=on'
	# retrieve dbpedia-Link from query results
	for l in urllib.urlopen(query_url):
		if '<td>' in l:
			# get dbpedia link and save in link file
			dbpedia_link = l.strip().replace('<td>','').replace('</td>','')
			log('              FOUND: ' +  dbpedia_link)
			link_file.write('<http://d-nb.info/gnd/' + gnd_identifier + '> owl:sameAs <' + dbpedia_link + '>\n')
			# save rdf file on disk
			rdf_link = dbpedia_link.replace('/resource/', '/data/') + '.rdf'
			urllib.urlretrieve(rdf_link, folder + rdf_link.rsplit("/",1)[1])
		
	
# Close all open files.
# print('Closing files...')
log('Closing files...')
input_file.close()
link_file.close()
print('DONE!')