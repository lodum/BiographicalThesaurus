# Read input file.
print('Reading input file...')
inputfile = open('XXXXX.txt', 'r') # TBD: insert correct filename!!!

# Create output file.
print('Creating output file...')
outputfile = open('E:/RDF/stis_rdflinks.txt', 'w')

# For each line in the input file...
print('Processing links...')
for line in inputfile:
	# format a link to the rdf-resource...
	rdflink = line.split(' ')[2].replace('page', 'data').replace('<','').replace('>','.rdf')
	# and write the formatted rdf-link to a line of the output file.
	outputfile.write(rdflink + '\n')

# Close all open files.
print('Closing files...')
inputfile.close()
outputfile.close()

print('DONE!')